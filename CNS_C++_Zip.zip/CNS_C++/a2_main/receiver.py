# Receiver.py
import socket
import random
import time
import math

def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def extended_gcd(a, b):
    if a == 0: 
        return (b, 0, 1)
    gcd_val, x1, y1 = extended_gcd(b % a, a) # a×x+b×y=gcd(a,b)
    x = y1 - (b // a) * x1 # Floor divisionb, x and y are coefficients
    y = x1
    return gcd_val, x, y

def mod_inverse(e, phi):
    gcd_val, x, _ = extended_gcd(e, phi) # e∗x+phi∗y=gcd(e,phi)
    if gcd_val != 1:
        raise ValueError("Inverse doesn't exist")
    return x % phi

# Randomly selects an integer e that is coprime with φ(n).
def find_coprime(phi):
    while True:
        e = random.randint(2, phi - 1) # Keeps generating a random integer e between 2 and phi - 1.
        if gcd(e, phi) == 1:
            return e

class Receiver:
    def __init__(self, d, n):
        self.d = d
        self.n = n

    def decrypt(self, cipherText):
        start_time = time.perf_counter()
        decrypted_text = pow(cipherText, self.d, self.n)
        decryption_time = time.perf_counter() - start_time
        return decrypted_text, decryption_time

def main():
    try:
        p = int(input("Enter first Prime Number (p): ").strip())
        q = int(input("Enter second Prime Number (q): ").strip())
    except ValueError:
        print("Please enter valid integers for p and q.")
        return

    if not (is_prime(p) and is_prime(q)):
        print("Both p & q must be prime. Exiting.")
        return

    n = p * q
    phi = (p - 1) * (q - 1)
    e = find_coprime(phi)
    d = mod_inverse(e, phi)

    print(f"\nGenerated Public Key:  e={e}, n={n}")
    print(f"Generated Private Key: d={d}, n={n}\n")

    receiver = Receiver(d, n)

    HOST = 'localhost'
    PORT = 65432

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen(1)
        print(f"Receiver: Listening on {HOST}:{PORT} ...")
        conn, addr = s.accept()
        with conn:
            print(f"Receiver: Connected by {addr}")
            public_key = f"{e},{n}"
            conn.sendall(public_key.encode())
            print("Receiver: Public Key sent to Sender.")

            data = conn.recv(4096)
            if not data:
                print("Receiver: No data received.")
                return
            try:
                cipherText = int(data.decode())
            except ValueError:
                print("Receiver: Received non-integer ciphertext.")
                return

            print(f"Receiver: Ciphertext received: {cipherText}")
            decrypted_text, decryption_time = receiver.decrypt(cipherText)
            print(f"Receiver: Decrypted Text is: {decrypted_text}")
            print(f"Decryption Time: {decryption_time:.6f} seconds")

if __name__ == "__main__":
    main()
