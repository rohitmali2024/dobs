#include <iostream>
#include <string>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <ctime>
#pragma comment(lib, "ws2_32.lib")

using namespace std;

long long mod_pow(long long base, long long exp, long long mod) {
    long long result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp & 1)
            result = (result * base) % mod;
        exp >>= 1;
        base = (base * base) % mod;
    }
    return result;
}

class Sender {
    long long e, n;
public:
    Sender(long long e, long long n) : e(e), n(n) {}
    pair<long long, double> encrypt(long long plaintext) {
        clock_t start = clock();
        long long cipherText = mod_pow(plaintext, e, n);
        double duration = double(clock() - start) / CLOCKS_PER_SEC;
        return { cipherText, duration };
    }
};

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cout << "WSAStartup failed.\n";
        return 1;
    }

    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == INVALID_SOCKET) {
        cout << "Socket creation failed.\n";
        WSACleanup();
        return 1;
    }

    sockaddr_in serv_addr{};
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(65432);
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

    cout << "Sender: Connecting to receiver...\n";
    if (connect(sock, (sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        cout << "Connection failed. Run receiver first.\n";
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    char buffer[4096] = {0};
    recv(sock, buffer, sizeof(buffer), 0);
    string data(buffer);
    size_t comma = data.find(',');
    long long e = stoll(data.substr(0, comma));
    long long n = stoll(data.substr(comma + 1));
    cout << "Sender: Received public key (e=" << e << ", n=" << n << ")\n";

    long long plaintext;
    while (true) {
        cout << "Enter integer plaintext (< n): ";
        cin >> plaintext;
        if (plaintext > 0 && plaintext < n) break;
        cout << "Invalid input. Try again.\n";
    }

    Sender sender(e, n);
    auto [cipherText, enc_time] = sender.encrypt(plaintext);
    cout << "Sender: Ciphertext = " << cipherText << "\n";
    cout << "Encryption time: " << enc_time << " sec\n";

    string msg = to_string(cipherText);
    send(sock, msg.c_str(), msg.size(), 0);
    cout << "Sender: Ciphertext sent.\n";

    closesocket(sock);
    WSACleanup();
    return 0;
}
