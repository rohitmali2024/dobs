#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <string>
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

using namespace std;

// ---------------- Helper Functions ----------------

bool is_prime(long long n) {
    if (n <= 1) return false;
    for (long long i = 2; i <= sqrt(n); i++)
        if (n % i == 0) return false;
    return true;
}

long long gcd(long long a, long long b) {
    while (b) {
        long long t = b;
        b = a % b;
        a = t;
    }
    return a;
}

long long mod_inverse(long long e, long long phi) {
    long long t = 0, newt = 1;
    long long r = phi, newr = e;
    while (newr != 0) {
        long long q = r / newr;
        long long temp = newt;
        newt = t - q * newt;
        t = temp;
        temp = newr;
        newr = r - q * newr;
        r = temp;
    }
    if (r > 1) throw runtime_error("e is not invertible");
    if (t < 0) t += phi;
    return t;
}

long long mod_pow(long long base, long long exp, long long mod) {
    long long result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp & 1)
            result = (result * base) % mod;
        exp >>= 1;
        base = (base * base) % mod;
    }
    return result;
}

// ---------------- Receiver Class ----------------
class Receiver {
    long long d, n;
public:
    Receiver(long long d, long long n) : d(d), n(n) {}
    pair<long long, double> decrypt(long long ciphertext) {
        clock_t start = clock();
        long long decrypted = mod_pow(ciphertext, d, n);
        double duration = double(clock() - start) / CLOCKS_PER_SEC;
        return { decrypted, duration };
    }
};

// ---------------- Main ----------------
int main() {
    long long p, q;
    cout << "Enter first Prime Number (p): ";
    cin >> p;
    cout << "Enter second Prime Number (q): ";
    cin >> q;

    if (!is_prime(p) || !is_prime(q)) {
        cout << "Both numbers must be prime.\n";
        return 0;
    }

    long long n = p * q;
    long long phi = (p - 1) * (q - 1);
    srand((unsigned)time(0));
    long long e;
    do { e = rand() % (phi - 2) + 2; } while (gcd(e, phi) != 1);
    long long d = mod_inverse(e, phi);

    cout << "\nPublic Key:  (e=" << e << ", n=" << n << ")\n";
    cout << "Private Key: (d=" << d << ", n=" << n << ")\n";

    // --- Initialize Winsock ---
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cout << "WSAStartup failed.\n";
        return 1;
    }

    SOCKET server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == INVALID_SOCKET) {
        cout << "Socket creation failed.\n";
        WSACleanup();
        return 1;
    }

    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(65432);

    if (bind(server_fd, (sockaddr*)&address, sizeof(address)) == SOCKET_ERROR) {
        cout << "Bind failed.\n";
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    listen(server_fd, 1);
    cout << "\nReceiver: Listening on port 65432...\n";

    sockaddr_in clientAddr;
    int addrLen = sizeof(clientAddr);
    SOCKET new_socket = accept(server_fd, (sockaddr*)&clientAddr, &addrLen);
    if (new_socket == INVALID_SOCKET) {
        cout << "Accept failed.\n";
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    string pubKey = to_string(e) + "," + to_string(n);
    send(new_socket, pubKey.c_str(), pubKey.size(), 0);
    cout << "Receiver: Sent public key.\n";

    char buffer[4096] = {0};
    recv(new_socket, buffer, sizeof(buffer), 0);
    long long cipherText = atoll(buffer);
    cout << "Receiver: Ciphertext received: " << cipherText << "\n";

    Receiver receiver(d, n);
    auto [decrypted, time_taken] = receiver.decrypt(cipherText);

    cout << "Receiver: Decrypted text is: " << decrypted << "\n";
    cout << "Decryption time: " << time_taken << " sec\n";

    closesocket(new_socket);
    closesocket(server_fd);
    WSACleanup();
    return 0;
}
