let users = {};
let loginAttempts = {};
const MAX_ATTEMPTS = 3;

// Pepper (server secret, simulated)
const PEPPER = "S3cr3tPepperValue";

// Generate random salt
function generateSalt(length = 16) {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let salt = "";
  for (let i = 0; i < length; i++) {
    salt += charset.charAt(Math.floor(Math.random() * charset.length));
  }
  return salt;
}

// Hash password using SHA-256 (async)
async function hashPassword(password, salt) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + salt + PEPPER);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
  return hashHex;
}

// Password strength checker
function isStrongPassword(password) {
  const strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!#%*?&])[A-Za-z\d@$!#%*?&]{8,}$/;
  return strongRegex.test(password);
}

// Sign-up logic
async function signUp() {
  const user = document.getElementById("signupUser").value.trim();
  const pass = document.getElementById("signupPass").value.trim();
  const msg = document.getElementById("signupMsg");

  if (!user || !pass) {
    msg.textContent = "⚠️ Enter username and password.";
    msg.style.color = "red";
    return;
  }

  if (!isStrongPassword(pass)) {
    msg.textContent = "⚠️ Weak password! Use A-Z, a-z, 0-9, symbol, and 8+ chars.";
    msg.style.color = "red";
    return;
  }

  if (users[user]) {
    msg.textContent = "⚠️ User already exists!";
    msg.style.color = "red";
    return;
  }

  const salt = generateSalt();
  const hash = await hashPassword(pass, salt);
  users[user] = { hash, salt };
  msg.textContent = "✅ Signup successful! You can login now.";
  msg.style.color = "green";
  console.log("Stored:", users);
}

// Login logic
async function login() {
  const user = document.getElementById("loginUser").value.trim();
  const pass = document.getElementById("loginPass").value.trim();
  const msg = document.getElementById("loginMsg");

  if (!users[user]) {
    msg.textContent = "❌ User not found.";
    msg.style.color = "red";
    return;
  }

  if (!loginAttempts[user]) loginAttempts[user] = 0;

  if (loginAttempts[user] >= MAX_ATTEMPTS) {
    msg.textContent = "🚫 Too many failed attempts. Account temporarily locked.";
    msg.style.color = "red";
    return;
  }

  const { hash, salt } = users[user];
  const enteredHash = await hashPassword(pass, salt);

  if (enteredHash === hash) {
    msg.textContent = "✅ Login successful!";
    msg.style.color = "green";
    loginAttempts[user] = 0;
  } else {
    loginAttempts[user]++;
    msg.textContent = `❌ Wrong password! Attempts: ${loginAttempts[user]}/${MAX_ATTEMPTS}`;
    msg.style.color = "red";
  }
}
